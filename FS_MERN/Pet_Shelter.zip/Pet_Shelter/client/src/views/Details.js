import React, { useEffect, useState } from 'react';
import axios from 'axios';
import {navigate} from '@reach/router';

const Details = (props) => {
    const { id } = props;
    const [pets, setPets] = useState([]);
    const [petName, setPetName] = useState("");
    const [petType, setPetType] = useState("");
    const [petDetails, setPetDetails] = useState("");
    const [petSkillOne, setPetSkillOne] = useState("");
    const [petSkillTwo, setPetSkillTwo] = useState("");
    const [petSkillThree, setPetSkillThree] = useState("");

    useEffect(() => {
        axios.get(`http://localhost:8000/api/pets/${id}`)
            .then((res) => {
                setPetName(res.data.petName)
                setPetType(res.data.petType)
                setPetDetails(res.data.petDetails)
                setPetSkillOne(res.data.petSkillOne)
                setPetSkillTwo(res.data.petSkillTwo)
                setPetSkillThree(res.data.petSkillThree);
            })
            .catch(err => console.log(err))
    }, [id])
    const deletePet = (petId) => {
        axios.delete(`http://localhost:8000/api/pets/${id}`)
            .then((res) => {
                setPets(pets.filter((pet) => pet._id !== petId));
                navigate("/");
            })
            .catch ((err) => console.log(err));
    }
    return (
        <div style={{margin: "50px", padding:"10px", border:"1px solid black"}}>
            <button style={{backgroundColor: "red", color:"white"}} onClick={(e) => { deletePet(pets._id) }}><b><u>Adopt</u>: {`${petName}`}<br />(they need you!)</b> </button>
            <p><u>Pet Name</u>: <b>{petName}</b></p>
            <p><u>Pet Type</u>: <b>{petType}</b></p>
            <p><u>Pet Details</u>: <b>{petDetails}</b></p>
            <p><u>Pet Skills</u>: <b>{petSkillOne}, {petSkillTwo}, {petSkillThree}</b></p>
            <button style={{backgroundColor: "blue", color: "white"}} onClick={() => {navigate("/")}}>Return Home... without your pet =[</button>
        </div>
    )
}



export default Details;