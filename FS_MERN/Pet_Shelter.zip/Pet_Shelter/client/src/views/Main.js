import AllPets from "../components/PetList";

const Main = () => {
    return (
        <AllPets />
    )
}

export default Main;