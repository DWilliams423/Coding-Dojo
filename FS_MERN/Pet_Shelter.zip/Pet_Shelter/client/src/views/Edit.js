import React, {useEffect,useState} from 'react';
import {navigate} from "@reach/router"
import axios from 'axios';

const Edit = (props) => {
    const {id} = props;
    const [petName,setPetName] = useState("");
    const [petType, setPetType] = useState("");
    const [petDetails, setPetDetails] = useState("");
    const [petSkillOne, setPetSkillOne] = useState("");
    const [petSkillTwo, setPetSkillTwo] = useState("");
    const [petSkillThree, setPetSkillThree] = useState("");
    const [errors,setErrors] = useState([]);

    useEffect(() => {
        axios.get(`http://localhost:8000/api/pets/${id}`)
            .then(res => {
                setPetName(res.data.petName)
                setPetType(res.data.petType)
                setPetDetails(res.data.petDetails)
                setPetSkillOne(res.data.petSkillOne)
                setPetSkillTwo(res.data.petSkillTwo)
                setPetSkillThree(res.data.petSkillThree);
            })
            .catch((err) => console.log(err))
    }, [id])
    const editPet = (e) => {
        e.preventDefault();
        const putEditData = {
            petName,
            petType,
            petDetails,
            petSkillOne,
            petSkillTwo,
            petSkillThree
        }
        axios.put(`http://localhost:8000/api/pets/${id}`, putEditData)
            .then((res) => {
                console.log(res.data)
                navigate("/");
            })
            .catch(err => {
                setErrors(err.response.data.errors);
            })
    }
    return (
        <div style={{margin: "50px", padding:"10px", border:"1px solid black"}}>
            <h1><u>Edit</u>: {`${petName}`}</h1>
            <form onSubmit={editPet}>
                <p>
                    <label className='label'><b>Pet Name:</b></label><br />
                    <input type="text"
                    name="petName"
                    value={petName}
                    onChange={(e) => {setPetName(e.target.value)}} />
                    {errors.petName ?
                        <p style={{color: "red"}}><em>{errors.petName.message}</em></p>
                        : null
                    }
                </p>
                <p>
                    <label><b>Pet Type:</b></label><br />
                    <input type="text"
                    name="petType"
                    value={petType}
                    onChange={(e) => {setPetType(e.target.value)}} />
                    {errors.petType ?
                        <p style={{color: "red"}}><em>{errors.petType.message}</em></p>
                        : null
                    }
                </p>
                <p>
                    <label><b>Pet Details:</b></label><br />
                    <input type="text"
                    name="petDetails"
                    value={petDetails}
                    onChange={(e) => {setPetDetails(e.target.value)}} />
                    {errors.petDetails ?
                        <p style={{color: "red"}}><em>{errors.petDetails.message}</em></p>
                        : null
                    }
                </p>
                <p>
                    <label><b>Pet Skill 1:</b></label><br />
                    <input type="text"
                    name="petSkillOne"
                    value={petSkillOne}
                    onChange={(e) => {setPetSkillOne(e.target.value)}} />
                </p>
                <p>
                    <label><b>Pet Skill 2:</b></label><br />
                    <input type="text"
                    name="petSkillTwo"
                    value={petSkillTwo}
                    onChange={(e) => {setPetSkillTwo(e.target.value)}} />
                </p>
                <p>
                    <label><b>Pet Skill 3:</b></label><br />
                    <input type="text"
                    name="petSkillThree"
                    value={petSkillThree}
                    onChange={(e) => {setPetSkillThree(e.target.value)}} />
                </p>
                <button style={{backgroundColor: "blue", color: "white", margin: "5px"}}>Submit Changes</button>
                <button style={{backgroundColor: "blue", color: "white"}} onClick={() => {navigate("/")}}>Return Home</button>
            </form>
        </div>
    )
}

export default Edit;