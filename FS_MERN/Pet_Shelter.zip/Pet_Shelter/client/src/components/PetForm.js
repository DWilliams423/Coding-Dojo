import React, { useState } from 'react';
import axios from 'axios';
import { Link, navigate } from '@reach/router';

const PetForm = () => {
    const [petName, setPetName] = useState("");
    const [petType, setPetType] = useState("");
    const [petDetails, setPetDetails] = useState("");
    const [petSkillOne, setPetSkillOne] = useState("");
    const [petSkillTwo, setPetSkillTwo] = useState("");
    const [petSkillThree, setPetSkillThree] = useState("");
    const [errors,setErrors] = useState([]);

    const onSubmitHandler = e => {
        e.preventDefault();
        axios.post('http://localhost:8000/api/pets', {
            petName,
            petType,
            petDetails,
            petSkillOne,
            petSkillTwo,
            petSkillThree
        })
            .then((res) => {
                console.log(res)
                navigate("/");
            })
            .catch(err => {
                setErrors(err.response.data.errors);
            })
    }
    return (
        <div style={{margin: "50px", padding:"10px", border:"1px solid black"}}>
            <form onSubmit={onSubmitHandler}>
                <h1>Add a pet to our adoption registry!</h1>
                <Link to="/">
                <button style={{backgroundColor: "blue", color: "white"}} onClick={() => {navigate("/")}}>Return Home</button>
                </Link>
                <p>
                    <label style={{margin: "5px"}}><b>Pet Name:</b></label>
                    <input type="text" onChange={(e) => setPetName(e.target.value)} />
                    {errors.petName ?
                        <p style={{color: "red"}}><em>{errors.petName.message}</em></p>
                        : null
                    }
                </p>
                <p>
                    <label style={{margin: "5px"}}><b>Pet Type:</b></label>
                    <input type="text" onChange={(e) => setPetType(e.target.value)} />
                    {errors.petType ?
                        <p style={{color: "red"}}><em>{errors.petType.message}</em></p>
                        : null
                    }
                </p>
                <p>
                    <label style={{margin: "5px"}}><b>Pet Details:</b></label>
                    <input type="text" onChange={(e) => setPetDetails(e.target.value)} />
                    {errors.petDetails ?
                        <p style={{color: "red"}}><em>{errors.petDetails.message}</em></p>
                        : null
                    }
                </p>
                <p>
                    <label style={{margin: "5px"}}><b>Pet Skill 1:</b></label>
                    <input type="text" onChange={(e) => setPetSkillOne(e.target.value)} />
                </p>
                <p>
                    <label style={{margin: "5px"}}><b>Pet Skill 2:</b></label>
                    <input type="text" onChange={(e) => setPetSkillTwo(e.target.value)} />
                </p>
                <p>
                    <label style={{margin: "5px"}}><b>Pet Skill 3:</b></label>
                    <input type="text" onChange={(e) => setPetSkillThree(e.target.value)} />
                </p>
                <input type="submit" style={{backgroundColor: "red", color: "white"}} />
            </form>
        </div>

    )
}

export default PetForm;