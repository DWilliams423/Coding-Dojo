import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link, navigate } from '@reach/router';

const AllPets = (props) => {
    const [petList,setPetList] = useState([])
    useEffect(() => {
        axios.get('http://localhost:8000/api/pets')
            .then(response => {
                setPetList(response.data);
            })
            .catch((err) => console.log(err.response))
    }, [])

    return (
        <div>
            <header>
                <h2>Check out some of our great pets!</h2>
            </header>
            <table style={{margin: "auto", padding: "5px", border:"1px solid black", backgroundColor: "lightsalmon"}}>
                <thead>
                    <tr>
                        <th><u>Pet Name</u></th>
                        <th><u>Type</u></th>
                        <th><u>Actions</u></th>
                    </tr>
                </thead>
                <tbody style={{border: "1px solid black", backgroundColor: "white", color: "black"}}>
                    {
                        petList?
                        petList.map((pet,index) => (
                            <tr key={index}>
                                <td><b>{pet.petName}</b></td>
                                <td><b>{pet.petType}</b></td>
                                <td>
                                    <button style={{backgroundColor: "lightcoral", color:"white"}} onClick ={() => {navigate(`/edit/${pet._id}`)}}>Edit</button>
                                    |
                                    <button style={{backgroundColor: "lightcoral", color:"white"}} onClick ={() => {navigate(`/details/${pet._id}`)}}>Details</button>
                                </td>
                            </tr>
                        ))
                        :null
                    }
                </tbody>
            </table>
            <Link to="/register/"><button style={{padding: "10px", margin:"10px", border: "3px solid black", backgroundColor: "red", color: "white"}}><b>Add to our adoption registry!</b></button></Link>
        </div>
    )
}
export default AllPets;