import PetForm from './components/PetForm';
import { Router } from '@reach/router';
import './App.css';
import Main from './views/Main';
import Details from './views/Details';
import Edit from './views/Edit';

function App() {
  return (
    <div className="App">
      <h1>Dan's Pet Shelter</h1>
      <Router>
        <Main path="/" />
        <PetForm path="register" />
        <Details path="details/:id" />
        <Edit path="edit/:id" />
      </Router>
      
    </div>
  );
}

export default App;
