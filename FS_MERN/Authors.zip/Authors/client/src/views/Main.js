import React, {useEffect,useState} from 'react'
import axios from 'axios'
// import AuthorForm from '../components/AuthorForm'
import AuthorList from '../components/AuthorList'
import { Link } from '@reach/router'

const Main = () => {
    // const [message,setMessage] = useState("Loading...")
    // useEffect(() => {
    //     axios.get("http://localhost:8000/api")
    //         .then(res => setMessage(res.data.message))
    // }, []);
    // return (
    //     <div>
    //         <h2>Message from the backend: {message}</h2>
    //     </div>
    // )
    const [authors,setAuthors] = useState([]);
    const [loaded,setLoaded] = useState(false);
    useEffect(() => {
        axios.get('http://localhost:8000/api/authors')
            .then(res => {
                setAuthors(res.data);
                setLoaded(true);
            });
    }, [])
    const removeFromDom = authorId => {
        setAuthors(authors.filter(author => author._id !== authorId));
    }
    return (
        <div>
            <h1>Favorite Authors</h1>
            <Link to="/authors/create">
                Add an Author
            </Link>
            {/* <h1>Favorite Authors</h1>
            <AuthorForm />
            <hr /> */}
            {loaded && <AuthorList authors = {authors} removeFromDom = {removeFromDom} />}
        </div>
    )
}

export default Main;