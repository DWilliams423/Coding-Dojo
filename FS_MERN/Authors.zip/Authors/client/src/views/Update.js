import React, {useEffect,useState} from 'react';
import axios from 'axios';

const Update = (props) => {
    const {id} = props;
    const [authorName,setAuthorName] = useState();

    useEffect(() => {
        axios.get('http://localhost:8000/api/authors/' + id)
            .then(res => {
                setAuthorName(res.data.authorName);
            })
            .catch(err => console.log(err))
    }, [])
    const updateAuthor = (e) => {
        e.prevent.default();
        axios.put('http://localhost:8000/api/authors/' + id, {
            authorName,
        })
            .then(res => console.log(res));
    }
    return (
        <div>
            <h1>Update an Author</h1>
            <form onSubmit={updateAuthor}>
                <p>
                    <label>Author Name</label><br />
                    <input type="text"
                    name="authorName"
                    value={authorName}
                    onChange={(e) => {setAuthorName(e.target.value)}} />
                </p>
                <input type="submit" />
            </form>
        </div>
    )
}

export default Update;