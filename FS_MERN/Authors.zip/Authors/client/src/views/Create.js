import AuthorForm from "../components/AuthorForm"

const Create = () => {
    return (
        <div>
            <AuthorForm />
        </div>
        
    )
}

export default Create;