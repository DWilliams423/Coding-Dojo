// import AuthorForm from './components/AuthorForm';
// import AuthorList from './components/AuthorList';
import Main from './views/Main';
import Detail from './views/Details';
import Update from './views/Update';
import { Router } from '@reach/router';
import './App.css';
import Create from './views/Create';

function App() {
  return (
    <div className="App">
      {/* <AuthorForm />
      <AuthorList /> */}
      <Router>
        <Main path="/" />
        <Detail path="/authors/:id" />
        <Update path="/authors/:id/edit" />
        <Create path="/authors/create" />
      </Router>
    </div>
  );
}

export default App;
