import axios from 'axios';
import React, { useEffect, useState } from 'react';
import { Link } from '@reach/router';

const AuthorList = (props) => {
    const [authorResFromApi,setAuthorResFromApi] = useState([]);
    useEffect(() => {
        axios.get('http://localhost:8000/api/authors')
            .then(response => {
                setAuthorResFromApi(response.data);
            })
            .catch((err) => console.log(err.response))
    }, [])
    const { removeFromDom, authors } = props;
    const deleteAuthor = (authorId) => {
        axios.delete('http://localhost:8000/api/authors/' + authorId)
            .then(res => {
                removeFromDom(authorId)
            })
            .catch(err => console.log(err))
    }
    return (
        <div>
            <h2>Your Faves</h2>
            <table>
                <thread>
                    <tr>
                        <th>Authors</th>
                        <th>Actions</th>
                    </tr>
                </thread>
                <tbody>
                    {authorResFromApi && authorResFromApi.map((element) => {
                            return <p key={element._id}>{element.name}</p>
                    })}
                    <tr>
                        <td></td>
                        <td></td>
                    </tr>
                </tbody>
            </table>
            {
                authors.map((author, index) => {
                return (
                    <div key={index}>
                        <Link to={"/authors/" + author._id}>
                            {author.authorName},
                        </Link>
                        |
                        <Link to={"/authors/" + author._id + "/edit"}>
                            <button>Edit</button>
                        </Link>
                        |
                        <button onClick={(e) => { deleteAuthor(author._id) }}>
                            Delete
                        </button>
                    </div>
                )})
            }
        </div>
    )
}

export default AuthorList;