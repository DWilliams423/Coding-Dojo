import React, {useState} from 'react';
import axios from 'axios';
import {Link,navigate} from '@reach/router';

const AuthorForm = () => {
    const [authorName,setAuthorName] = useState("");

    const onSubmitHandler = e => {
        e.preventDefault();
        axios.post('http://localhost:8000/api/authors', {
            authorName,
        })
            .then(res => console.log(res))
            .catch(err => console.log(err))
    }
    return (
        <form onSubmit={onSubmitHandler}>
            <h1>Add to Your Favorite Authors</h1>
            <Link to="/">
                Back to your list
            </Link>
            <p>
                <label>Author Name:</label>
                <input type="text" onChange = {(e) => setAuthorName(e.target.value)} />
            </p>
            <input type="submit" />
            {/* <button onClick={(navigate('Authors'))} type="submit">Submit</button> */}
        </form>
    )
}
// {errors && 
//     Object.keys(errors).map((errKey,index) => (
//         return (
//             <p>
//                 {errors[errKey].message}
//             </p>
//         )
//     ))
// }

export default AuthorForm;